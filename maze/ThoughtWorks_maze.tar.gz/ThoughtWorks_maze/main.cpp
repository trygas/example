
#include <iostream>
#include <vector>
#include <string>

#include "maze.h"
#include "parseline.h"
#include "accessgrid.h"

int main(void)
{
//    while (true)
//    {
        std::string str1 = "3 4";
        std::string str2 = "4,1 4,2";
        std::vector<int> grid_size;
        std::vector<zhangmi::AccessGrid> grid_connect_data;

        //input origin maze:rows cols
//        std::getline(std::cin,str1);
        if(!zhangmi::Parseline::instance().check_first_line(str1, grid_size))
//            continue;

        std::cout << "rows: " << grid_size[0] << "cols: " << grid_size[1] <<std::endl;

        zhangmi::Maze maze(grid_size);

       //input connected cell id
//        std::getline(std::cin, str2);
        zhangmi::Parseline::instance().check_second_line(str2, grid_connect_data);
//        if(!zhangmi::Parseline::instance().check_second_line(str2, grid_connect_data))
//            continue;
        maze.change_maze(grid_connect_data);
//        if(!maze.change_maze(grid_connect_data))
//            continue;

        maze.print_maze();
//    }

    return 0;
}
