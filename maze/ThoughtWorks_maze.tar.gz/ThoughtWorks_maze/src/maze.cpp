#include <iostream>
#include "maze.h"

namespace zhangmi
{
Maze::Maze(const int _row, const int _col)
{
    create_maze(_row, _col);
}

Maze::Maze(std::vector<int> _grid_size)
{
    create_maze(_grid_size[0], _grid_size[1]);
}

void Maze::print_maze()
{
    for(int i = 0; i < maze.size(); ++i)
    {
        for(int j = 0; j < maze[i].size(); ++j)
        {
            std::cout << maze[i][j] << " " ;
        }
        std::cout << std::endl;
    }
}

bool Maze::change_maze(const std::vector<zhangmi::AccessGrid> _access)
{
    for(int i = 0; i < _access.size(); ++i)
    {
        std::vector<int> answer_grid;

        if(!find_answer(_access[i], answer_grid))
            return false;
        maze[answer_grid[0]][answer_grid[1]].change('R');
    }
    return true;
}


bool Maze::find_answer(const zhangmi::AccessGrid& _access_grid, std::vector<int>& _answer_grid)
{
    if(_access_grid.find_access(_answer_grid))
    {
        if(_answer_grid[0] > maze.size() - 1 || _answer_grid[1] > maze[0].size() - 1)
        {
            std::cerr << "Number out of range.";
            return false;
        }
        else
            return true;
    }
    else
        return false;
}

void Maze::create_maze(int _row, int _col)
{
    Grid grid_hinder('W');
    Grid grid_access('R');

    std::vector<Grid> hinder = {grid_hinder};
    std::vector<Grid> hinder_access = {grid_hinder};
    for(int i = 0; i < _col; ++i)
    {
        hinder.push_back(grid_hinder);
        hinder.push_back(grid_hinder);
        hinder_access.push_back(grid_access);
        hinder_access.push_back(grid_hinder);
    }

    maze.push_back(hinder);
    for(int j = 0; j < _row; ++j)
    {
        maze.push_back(hinder_access);
        maze.push_back(hinder);
    }
}
}

