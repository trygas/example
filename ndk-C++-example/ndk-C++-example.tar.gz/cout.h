//
// Created by liu on 19-7-3.
//

#ifndef EXAMPLE_COUT_H
#define EXAMPLE_COUT_H

#include <vector>
#include "iostream"
#include "string"

int coutHelloworld();
std::vector<double> changeVectorDouble(std::vector<double> &someNum);
std::string changeString(std::string originString);
std::vector<double> generateVectorDouble();

#endif //EXAMPLE_COUT_H
